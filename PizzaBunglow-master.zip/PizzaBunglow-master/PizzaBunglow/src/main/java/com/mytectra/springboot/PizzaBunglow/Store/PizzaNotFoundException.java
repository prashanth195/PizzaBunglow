package com.mytectra.springboot.PizzaBunglow.Store;

public class PizzaNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PizzaNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public PizzaNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public PizzaNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public PizzaNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PizzaNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}

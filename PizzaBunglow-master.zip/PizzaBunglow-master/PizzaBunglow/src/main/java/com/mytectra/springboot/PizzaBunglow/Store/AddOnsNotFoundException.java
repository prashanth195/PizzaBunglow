package com.mytectra.springboot.PizzaBunglow.Store;

public class AddOnsNotFoundException extends Exception {

	public AddOnsNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public AddOnsNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public AddOnsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public AddOnsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AddOnsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}

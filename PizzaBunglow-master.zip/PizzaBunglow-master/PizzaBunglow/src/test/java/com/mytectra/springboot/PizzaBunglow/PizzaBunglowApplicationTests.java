package com.mytectra.springboot.PizzaBunglow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaBunglowApplicationTests {

	@Test
	void contextLoads() {
	}

}
